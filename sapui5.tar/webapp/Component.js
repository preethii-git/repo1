sap.ui.define([
     "sap/ui/core/UIComponent", 
     "sap/ui/model/json/JSONModel", 
     "sap/ui/model/resource/ResourceModel" ,
     "./controller/Dialog",
     "sap/ui/Device"
    ], function (UIComponent, JSONModel, ResourceModel, Dialog, Device) {  

     "use strict";
return UIComponent.extend("sapui5.Component", {

    metadata: {
            manifest: "json"
        
    },
      init: function () {
        UIComponent.prototype.init.apply(this, arguments);

        var oData = {
            id: {
              name: "UI5"
            }
          };
           
          var oModel = new JSONModel(oData);
         this.setModel(oModel);

         var oDeviceModel = new JSONModel(Device);
         oDeviceModel.setDefaultBindingMode("OneWay");
         this.setModel(oDeviceModel,"device");

        //  var i18nModel = new ResourceModel({
        //   bundleName:"ui5.i18n.i18n",
        //   supportedLocales: [""],
        //   fallbackLocale: ""

        // });
        // this.setModel(i18nModel,"i18n")

        this._Dialog = new Dialog(this.getRootControl());

        this.getRouter().initialize();
     
      },
        
         getContentDensityClass : function() {
           if(!this._sContentDensityClass) {
              if (!Device.support.touch) {
                  this._sContentClass = "sapUiSizeCompact";
              } else {
                  this._sContentDensityClass = "sapUiSizeCozy";
              }
           }
           return this._sContentDensityClass;
         },

      exit : function() {

        this._Dialog.destroy();
        delete this._Dialog;
      },

        openDialog : function (){
           this._Dialog.open();
        }

    });

});