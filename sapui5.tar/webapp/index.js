//sap.ui.define([


                               // THIS CODE FOR CONTROLS //
//  "sap/m/Text"

//], function (Text) {

//    "use strict";
    
//      new Text({
//         text:"Hello UI"          

//      }).placeAt("content")
//});

//                                    /// CODE FOR XML  ///
// "sap/ui/core/mvc/XMLView"

// ], function(XMLView){
    
//   "use strict";

//    XMLView.create({
//       viewName:"ui5.view.App"
//     }).then( function (OView) {
 
//       OView.placeAt("content");
//     });

//  });


                                // THIS CODE FOR COMPONENTS //

//      "sap/ui/core/ComponentContainer"   
     
// ], function (ComponentContainer) {
//       "use strict";

//       new ComponentContainer({
//         name: "ui5",
//          settings: {
//             id: "ui5"
//          },
//          async: true
//       }).placeAt("content");

//    });