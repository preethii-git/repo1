sap.ui.define([

  "sap/ui/core/mvc/Controller",
  //"sap/m/MessageToast",
  //"sap/ui/model/json/JSONModel",
  //"sap/ui/model/resource/ResourceModel"

], function (Controller){  //,JSONModel,ResourceModel ) {
    "use strict";
    return Controller.extend("sapui5.App",{ 

      onInit: function() {
        this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
      },

      onOpenDialog: function () {

         this.getOwnerComponent().openDialog();
      }
         

      // onInit: function () { 
      //   var oData = {
      //       id: {
      //         name: "UI5"
      //       }
      //   };
      //    var oModel = new JSONModel(oData);
      //    this.getView().setModel(oModel);
       
      //   var i18nModel = new ResourceModel({
      //     bundleName:"ui5.i18n.i18n",
      //     supportedLocales: [""],
      //     fallbackLocale: ""

      //   });

      //   this.getView().setModel(i18nModel,"i18n")
      // },

    // onshow : function () {

    //   //FOR CONTROLLER//
    //  //alert("Hello UI5!!");

    // // MessageToast.show("Hello UI5!!");

    // var oBundle = this.getView().getModel("i18n").getResourceBundle();
    // var sId = this.getView().getModel().getProperty("/id/name");
    // var sMsg = oBundle.getText("msg", [sId]);

    // MessageToast.show(sMsg);

    // }
   });
  });
