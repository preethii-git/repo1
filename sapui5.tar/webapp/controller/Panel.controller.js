sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/ui/core/Fragment"
], function(Controller, MessageToast, Fragment) {
    "use strict";

    return Controller.extend("sapui5.controller.Panel",{ 
    onshow : function () {

      //FOR CONTROLLER//
     //alert("Hello UI5!!");

    // MessageToast.show("Hello UI5!!");

    var oBundle = this.getView().getModel("i18n").getResourceBundle();
    var sId = this.getView().getModel().getProperty("/id/name");
    var sMsg = oBundle.getText("msg", [sId]);

    MessageToast.show(sMsg);

    },

       onOpenDialog : function () {

         this.getOwnerComponent().openDialog();

      //     var oView = this.getView();

      //     if (!this.byId("helloDialog")){
          
      //       Fragement.load({

      //           id:oView.getId(),
      //           name: "ui5.view.Dialog",
      //           controller: this
      //       }).then(function(oDialog){

      //         oView.addDependent(oDialog);
      //         oDialog.open();
      //       })

      //     } else {
      //         this.byId("Dialog").open();
      //     }
      //  },
      //  onCloseDialog: function(){
      //       this.byId("helloDialog").close();


           
        }
       

    });
});