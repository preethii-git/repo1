sap.ui.define([
	"comsap/mybank_details/test/unit/controller/App.controller"
], function () {
	"use strict";
});
